package KantineAanlevering;

public class Contant extends Betaalwijze {
    /**
     * Methode om betaling af te handelen
     */
    public boolean betaal(double tebetalen) {
        // method body omitted
        throw new UnsupportedOperationException();
    }
}